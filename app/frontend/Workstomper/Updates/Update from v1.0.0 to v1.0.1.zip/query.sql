-- Insert permissions for the 'web' guard
INSERT INTO permissions (name, guard_name)
VALUES 
    ('create_timesheet', 'web'),
    ('delete_timesheet', 'web'),
    ('manage_timesheet', 'web'),
    ('create_payslips', 'web'),
    ('edit_payslips', 'web'),
    ('delete_payslips', 'web'),
    ('manage_payslips', 'web');

-- Insert permissions for the 'client' guard
INSERT INTO permissions (name, guard_name)
VALUES 
    ('create_timesheet', 'client'),
    ('delete_timesheet', 'client'),
    ('manage_timesheet', 'client'),
    ('create_payslips', 'client'),
    ('edit_payslips', 'client'),
    ('delete_payslips', 'client'),
    ('manage_payslips', 'client');
