INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) 
VALUES 
(NULL, 'manage_estimates_invoices', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'create_estimates_invoices', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'edit_estimates_invoices', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'delete_estimates_invoices', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'manage_estimates_invoices', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'create_estimates_invoices', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'edit_estimates_invoices', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'delete_estimates_invoices', 'client', current_timestamp(), current_timestamp());

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) 
VALUES 
(NULL, 'manage_expenses', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'create_expenses', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'edit_expenses', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'delete_expenses', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'manage_expenses', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'create_expenses', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'edit_expenses', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'delete_expenses', 'client', current_timestamp(), current_timestamp());

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) 
VALUES 
(NULL, 'manage_milestones', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'create_milestones', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'edit_milestones', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'delete_milestones', 'web', current_timestamp(), current_timestamp()), 
(NULL, 'manage_milestones', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'create_milestones', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'edit_milestones', 'client', current_timestamp(), current_timestamp()), 
(NULL, 'delete_milestones', 'client', current_timestamp(), current_timestamp());
